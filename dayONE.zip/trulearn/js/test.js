async function test(){
    async function ayush(){return 5}
    let a = ayush()
    console.log(a)
    }
    test()